require 'yaml'

require 'webfontloader/modules'

module WebFontLoader
  VERSION = '1.5.4'

  ProjectRoot = File.expand_path(File.dirname(__FILE__) + "/..")

end
